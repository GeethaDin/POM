package com.leaftaps.ui.base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.leaftaps.ui.utils.ReadExcelData;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public RemoteWebDriver driver;
	public String fileName;
	 @Parameters({"browser","URL"})
	  @BeforeMethod
	  public void preConditions(String browser,String url) {
		 if(browser.equals("safari"))
		 {
		 WebDriverManager.safaridriver().setup();
		 driver = new SafariDriver();	
		 }
		 else 
		 {
			 WebDriverManager.chromedriver().setup();
			 driver = new ChromeDriver();	 
		 }
			driver.get(url);
			 driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));		
	  }
	  @AfterMethod
	public void postConditions()
	{
		driver.close();
	}
	  
	  @DataProvider
	  public String[][] testData() throws IOException
	  {
		  return ReadExcelData.getData(fileName);

	  }

}
