package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.leaftaps.ui.base.BaseClass;

public class HomePage extends BaseClass{
	public HomePage(RemoteWebDriver driverValue)
	{
		this.driver=driverValue;
	}
	public LeadsPage clickLeadsButton()
	{
		WebElement clickleadElement=driver.findElement(By.linkText("Leads"));
		clickleadElement.click();
		return new LeadsPage(driver);
	}

}
