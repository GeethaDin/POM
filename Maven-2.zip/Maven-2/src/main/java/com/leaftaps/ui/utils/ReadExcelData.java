package com.leaftaps.ui.utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {
	public static String[][] getData(String fileName) throws IOException
	{
	XSSFWorkbook book=new XSSFWorkbook("./data/"+fileName+".xlsx");
	XSSFSheet sheet=book.getSheetAt(0);
	int rowCount=sheet.getLastRowNum();
	int colCount=sheet.getRow(1).getLastCellNum();
	String[][] data = new String[rowCount][colCount];
	for(int i=1;i<=rowCount;i++)
	{
		for(int j=0;j<colCount;j++)
		{
			String sheetValue=sheet.getRow(i).getCell(j).getStringCellValue();
			data[i-1][j]=sheetValue;
		}
	}
	book.close();
	return data;
	}
	
}




