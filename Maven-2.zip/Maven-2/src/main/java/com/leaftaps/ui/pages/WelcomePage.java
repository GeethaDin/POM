package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.leaftaps.ui.base.BaseClass;

public class WelcomePage extends BaseClass{
	public WelcomePage(RemoteWebDriver driverValue)
	{
		this.driver=driverValue;
	}
	public HomePage clickCRMSFALink()
	{
		WebElement crmLinkElement=driver.findElement(By.linkText("CRM/SFA"));
		crmLinkElement.click();
		return new HomePage(driver);
	}
	public LoginPage clickLogOut()
	{
		WebElement loginButton=driver.findElement(By.className("decorativeSubmit"));
		loginButton.click();
		return new LoginPage(driver);
	}
	
}
