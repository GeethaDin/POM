package com.leaftaps.ui.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import com.leaftaps.ui.base.BaseClass;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPage extends BaseClass{
	public LoginPage(RemoteWebDriver driverValue)
	{
		this.driver=driverValue;
	}
	public LoginPage enterUserName(String userName)
	{
		WebElement userNameElement=driver.findElement(By.id("username"));
		userNameElement.sendKeys(userName);
		return this;
	}
	public LoginPage enterPassword(String password)
	{
		WebElement passwordElement=driver.findElement(By.name("PASSWORD"));
		passwordElement.sendKeys(password);
		return this;
	}
	public WelcomePage clickLoginButton()
	{
		WebElement clickLoginElement=driver.findElement(By.className("decorativeSubmit"));
		clickLoginElement.click();
		return new WelcomePage(driver);

	}

}
