package com.leaftaps.ui.tests;
import com.leaftaps.ui.pages.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.base.BaseClass;

public class CreateLead extends BaseClass{
	
	@BeforeTest
	public void setData()
	{
		fileName = "Book1";
	}
	@Test(dataProvider="testData")
	public void test(String userName,String password,String companyName,String firstName,String lastName)
	{
			new LoginPage(driver).enterUserName(userName).enterPassword(password).clickLoginButton().clickCRMSFALink().clickLeadsButton().clickCreateButton().enterCompanyName(companyName).enterFirstName(firstName).enterLastName(lastName).clickCreateButton2();
	}	
}
