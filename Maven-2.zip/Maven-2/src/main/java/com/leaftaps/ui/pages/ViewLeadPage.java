package com.leaftaps.ui.pages;

import java.time.Duration;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import com.leaftaps.ui.base.BaseClass;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ViewLeadPage extends BaseClass{
	public ViewLeadPage(RemoteWebDriver driverValue)
	{
		this.driver=driverValue;
	}
	public ViewLeadPage verifyLeadPage() {
		System.out.println("Lead Created");
		return this;
	}
	

}
