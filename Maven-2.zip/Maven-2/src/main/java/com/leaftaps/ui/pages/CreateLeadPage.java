package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.leaftaps.ui.base.BaseClass;

public class CreateLeadPage extends BaseClass {
	public CreateLeadPage(RemoteWebDriver driverValue)
	{
		this.driver=driverValue;
		
	}
	public CreateLeadPage enterCompanyName(String companyName)
	{
		WebElement companyElement=driver.findElement(By.id("createLeadForm_companyName"));
		companyElement.sendKeys(companyName);
		return this;
	}
	public CreateLeadPage enterFirstName(String firstName)
	{
		WebElement firstNameElement=driver.findElement(By.id("createLeadForm_firstName"));
		firstNameElement.sendKeys(firstName);
		return this;
	}
	public CreateLeadPage enterLastName(String lastName)
	{
		WebElement lastNameElement=driver.findElement(By.id("createLeadForm_lastName"));
		lastNameElement.sendKeys(lastName);
		return this;
		
	}
	public ViewLeadPage clickCreateButton2()
	{
		WebElement submitElement=driver.findElement(By.name("submitButton"));
		submitElement.click();
		return new ViewLeadPage(driver);

	}
	

}
